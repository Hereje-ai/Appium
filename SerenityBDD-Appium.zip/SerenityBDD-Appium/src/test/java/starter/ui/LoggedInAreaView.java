package starter.ui;

import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.findby.By;

public class LoggedInAreaView {
    public static Target welcomeText = Target
            .the("welcome text")
            .located(By.xpath("//android.widget.TextView[contains(@text, 'You are logged in')]"));
}
