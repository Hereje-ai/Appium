package starter.ui;

import io.appium.java_client.AppiumBy;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.findby.By;

public class HomeView {
    public static Target loginLink = Target
            .the("login")
            .located(By.xpath("(//android.widget.TextView[@text=\"\uE5CC\"])[2]"));
}
